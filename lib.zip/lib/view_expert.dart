
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
void main() {
  runApp(const view_expert());
}

class view_expert extends StatelessWidget {
  const view_expert({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'view_expert',debugShowCheckedModeBanner: false,
      theme: ThemeData(

        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const view_expertPage(title: 'view expert'),
    );
  }
}

class view_expertPage extends StatefulWidget {
  const view_expertPage({super.key, required this.title});


  final String title;

  @override
  State<view_expertPage> createState() => _view_expertPageState();
}

class _view_expertPageState extends State<view_expertPage> {

  _view_expertPageState() {
    view_expert();
  }

  List<String> name_ = <String>[];
  List<String> email_ = <String>[];
  List<String> phone_ = <String>[];
  List<String> place_ = <String>[];
  List<String> pin_ = <String>[];
  List<String> district_ = <String>[];
  List<String> photo_ = <String>[];



  Future<void> view_expert() async {
  List<String> name = <String>[];
  List<String> email = <String>[];
  List<String> phone = <String>[];
  List<String> place = <String>[];
  List<String> pin = <String>[];
  List<String> district = <String>[];
  List<String> photo = <String>[];


  try {
  SharedPreferences sh = await SharedPreferences.getInstance();
  String urls = sh.getString('url').toString();
  String url = '$urls/Myapp/view_expert/';

  var data = await http.post(Uri.parse(url), body: {


  });
  var jsondata = json.decode(data.body);
  String statuss = jsondata['status'];

  var arr = jsondata["data"];

  print(arr.length);

  for (int i = 0; i < arr.length; i++) {
  name.add(arr[i]['name'].toString());
  email.add(arr[i]['email']);
  phone.add(arr[i]['phone']);
  place.add(arr[i]['place']);
  pin.add(arr[i]['pin']);
  district.add(arr[i]['district']);
  photo.add(arr[i]['photo']);


  }

  setState(() {
  name_ = name;
  email_ = email;
  phone_ = phone;
  place_ = place;
  pin_ = pin;
  district_ = district;
  photo_ = photo;

  });

  print(statuss);
  } catch (e) {
  print("Error ------------------- " + e.toString());
  //there is error during converting file image to base64 encoding.
  }
}

@override
Widget build(BuildContext context) {
  // This method is rerun every time setState is called, for instance as done
  // by the _incrementCounter method above.
  //
  // The Flutter framework has been optimized to make rerunning build methods
  // fast, so that you can just rebuild anything that needs updating rather
  // than having to individually change instances of widgets.
  return Scaffold(
      appBar: AppBar(
        leading: BackButton( ),
        // TRY THIS: Try changing the color here to a specific color (to
        // Colors.amber, perhaps?) and trigger a hot reload to see the AppBar
        // change color while the other colors stay the same.
        backgroundColor: Theme.of(context).colorScheme.primary,

        title: Text(widget.title),
      ),
      body: ListView.builder(
        physics: BouncingScrollPhysics(),
        // padding: EdgeInsets.all(5.0),
        // shrinkWrap: true,
        itemCount: name_.length,
        itemBuilder: (BuildContext context, int index) {
          return ListTile(
            onLongPress: () {
              print("long press" + index.toString());
            },
            title: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    Card(
                      child:
                      Row(
                          children: [
                            CircleAvatar(radius: 50,backgroundImage: NetworkImage(name_[index])),
                            Column(
                              children: [
                                Padding(
                                  padding: EdgeInsets.all(5),
                                  child: Text(email_[index]),
                                ),
                                Padding(
                                  padding: EdgeInsets.all(5),
                                  child: Text(phone_[index]),
                                ),
                                Padding(
                                  padding: EdgeInsets.all(5),
                                  child: Text(place_[index]),
                                ),Padding(
                                  padding: EdgeInsets.all(5),
                                  child: Text(pin_[index]),
                                ),Padding(
                                  padding: EdgeInsets.all(5),
                                  child: Text(district_[index]),
                                ),Padding(
                                  padding: EdgeInsets.all(5),
                                  child: Text(photo_[index]),
                                ),
                              ],
                            ),
                            // ElevatedButton(
                            //   onPressed: () async {
                            //
                            //     final pref =await SharedPreferences.getInstance();
                            //     pref.setString("did", id_[index]);
                            //
                            //     Navigator.push(
                            //       context,
                            //       MaterialPageRoute(builder: (context) => ViewSchedule()),
                            //     );
                            //
                            //
                            //
                            //
                            //   },
                            //   child: Text("Schedule"),
                            // ),
                          ]
                      )

                      ,
                      elevation: 8,
                      margin: EdgeInsets.all(10),
                    ),
                  ],
                )),
          );
        },
      )
    // This trailing comma makes auto-formatting nicer for build methods.
  );
}
}