import 'package:fluttertoast/fluttertoast.dart';
import 'package:flutter/material.dart';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'login.dart';


void maim() {
 runApp(const SetIp());
}

class SetIp extends StatelessWidget {
  const SetIp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: SetIpPage(title: '',),
    );
  }
}



class SetIpPage extends StatefulWidget {
const SetIpPage({super.key, required this.title});

final String title;

@override
State<SetIpPage> createState() =>_SetIpPageState();
}
class _SetIpPageState extends State<SetIpPage> {

  TextEditingController ipController = new TextEditingController();


  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        return true;
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Theme
              .of(context)
              .colorScheme
              .inversePrimary,
          title: Text(widget.title),
        ), // AppBar

        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[

              Padding(
                padding: const EdgeInsets.all(8),
                child: TextField(
                  controller: ipController,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(), label: Text("Ip Address")),
                ), // TextField
              ), // Padding

              ElevatedButton(
                onPressed: () async {
                  String ip = ipController.text.toString();
                  var sh = await SharedPreferences.getInstance();
                  sh.setString("url", "http://" + ip + ":8000/myapp/");
                  sh.setString("imgurl", "http://" + ip + ":8000");

                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => MyLoginPage(title: '',)),
                  );
                },
                child: Text("SetIp"),


              ), // ElevatedButton
            ], // <Widget>[]
          ), // Colunh
        ), // SingleChildScrollView
      ), // Scaffold
    ); // WillPopScope
  }

}