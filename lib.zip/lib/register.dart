import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../login.dart';

class UserRegisterPage extends StatefulWidget {
  const UserRegisterPage({Key? key}) : super(key: key);

  @override
  State<UserRegisterPage> createState() => _UserRegisterPageState();
}

class _UserRegisterPageState extends State<UserRegisterPage> {
  final _formKey = GlobalKey<FormState>();

  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();
  final placeController = TextEditingController();
  final pincodeController = TextEditingController();
  final districtController = TextEditingController();
  final genderController = TextEditingController();
  final dobController = TextEditingController();
  final usernameController = TextEditingController();
  final passwordController = TextEditingController();

  XFile? _photo;

  bool _isLoading = false;
  bool _obscure = true;

  final Color primary = const Color(0xFFF96332);
  final Color bg = const Color(0xFFF7F7F7);

  // Pick Image
  Future<void> _pickImage() async {
    final img = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (img != null) setState(() => _photo = img);
  }

  // Register (MULTIPART POST REQUEST)
  Future<void> _register() async {
    if (!_formKey.currentState!.validate()) return;

    if (_photo == null) {
      Fluttertoast.showToast(msg: "Please select a profile photo");
      return;
    }

    setState(() => _isLoading = true);

    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? url = prefs.getString("url");

      if (url == null || url.isEmpty) {
        Fluttertoast.showToast(msg: "Server URL missing in SharedPreferences");
        return;
      }

      var request = http.MultipartRequest(
        "POST",
        Uri.parse(url + "android_user_registration/"),
      );

      // Add form fields
      request.fields.addAll({
        "name": nameController.text.trim(),
        "email": emailController.text.trim(),
        "phone": phoneController.text.trim(),
        "place": placeController.text.trim(),
        "pincode": pincodeController.text.trim(),
        "district": districtController.text.trim(),
        "gender": genderController.text.trim(),
        "dob": dobController.text.trim(),
        "username": usernameController.text.trim(),
        "password": passwordController.text.trim(),
      });

      request.files.add(
        await http.MultipartFile.fromPath(
          'photo',
          _photo!.path,
        ),
      );

      var response = await request.send();
      String resString = await response.stream.bytesToString();
      var data = jsonDecode(resString);

      if (data["task"] == "ok") {
        Fluttertoast.showToast(msg: "Registration Successful!");

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (_) => const MyLoginPage(title: "",)),
        );
      } else {
        Fluttertoast.showToast(msg: "Registration Failed");
      }
    } catch (e) {
      Fluttertoast.showToast(msg: "Error: $e");
    }

    setState(() => _isLoading = false);
  }

  // UI
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        title: const Text("User Registration"),
        backgroundColor: primary,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(18),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              GestureDetector(
                onTap: _pickImage,
                child: CircleAvatar(
                  radius: 55,
                  backgroundColor: Colors.white,
                  backgroundImage: _photo != null
                      ? FileImage(File(_photo!.path))
                      : null,
                  child: _photo == null
                      ? Icon(Icons.camera_alt_outlined,
                      color: primary, size: 36)
                      : null,
                ),
              ),

              const SizedBox(height: 20),

              _buildInput(nameController, "Full Name", Icons.person),
              _buildInput(emailController, "Email", Icons.email_outlined),
              _buildInput(phoneController, "Phone", Icons.phone),
              _buildInput(placeController, "Place", Icons.place),
              _buildInput(pincodeController, "Pincode", Icons.location_on),
              _buildInput(districtController, "District", Icons.location_city),
              _buildInput(genderController, "Gender", Icons.person_outline),
              _buildInput(dobController, "DOB", Icons.date_range),
              _buildInput(usernameController, "Username", Icons.person_outline),

              _buildInput(
                passwordController,
                "Password",
                Icons.lock_outline,
                obscure: _obscure,
                suffix: IconButton(
                  icon: Icon(
                    _obscure ? Icons.visibility_off : Icons.visibility,
                  ),
                  onPressed: () =>
                      setState(() => _obscure = !_obscure),
                ),
              ),

              const SizedBox(height: 24),

              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50),
                  backgroundColor: primary,
                ),
                onPressed: _isLoading ? null : _register,
                child: _isLoading
                    ? const CircularProgressIndicator(
                    color: Colors.white)
                    : const Text("Register",
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInput(
      TextEditingController c,
      String label,
      IconData icon, {
        bool obscure = false,
        Widget? suffix,
      }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: TextFormField(
        controller: c,
        obscureText: obscure,
        validator: (v) => v!.isEmpty ? "Enter $label" : null,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon, color: primary),
          suffixIcon: suffix,
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }
}
