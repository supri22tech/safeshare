
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
void main() {
  runApp(const view_parants());
}

class view_parants extends StatelessWidget {
  const view_parants({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'view_parants',debugShowCheckedModeBanner: false,
      theme: ThemeData(

        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const view_parantsPage(title: 'view parants'),
    );
  }
}

class view_parantsPage extends StatefulWidget {
  const view_parantsPage({super.key, required this.title});


  final String title;

  @override
  State<view_parantsPage> createState() => _view_parantsPageState();
}

class _view_parantsPageState extends State<view_parantsPage> {

  _view_parantsPageState() {
    view_parants();
  }

  List<String> name_ = <String>[];
  List<String> email_ = <String>[];
  List<String> phone_ = <String>[];
  List<String> Housename_ = <String>[];
  List<String> place_ = <String>[];



  Future<void> view_parants() async {
    List<String> name = <String>[];
    List<String> email = <String>[];
    List<String> phone = <String>[];
    List<String> Housename = <String>[];
    List<String> place = <String>[];


    try {
      SharedPreferences sh = await SharedPreferences.getInstance();
      String urls = sh.getString('url').toString();
      String url = '$urls/view_image_notification/';

      var data = await http.post(Uri.parse(url), body: {


      });
      var jsondata = json.decode(data.body);
      String statuss = jsondata['status'];

      var arr = jsondata["data"];

      print(arr.length);

      for (int i = 0; i < arr.length; i++) {
        name.add(arr[i]['name'].toString());
        email.add(arr[i]['email']);
        phone.add(arr[i]['phone']);
        Housename.add(arr[i]['Housename']);
        place.add(arr[i]['place_']);


      }

      setState(() {
        name_ = name;
        email_ = email;
        phone_ = phone;
        Housename_ = Housename;
        place_ = place;

      });

      print(statuss);
    } catch (e) {
      print("Error ------------------- " + e.toString());
      //there is error during converting file image to base64 encoding.
    }
  }

  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
        appBar: AppBar(
          leading: BackButton( ),
          // TRY THIS: Try changing the color here to a specific color (to
          // Colors.amber, perhaps?) and trigger a hot reload to see the AppBar
          // change color while the other colors stay the same.
          backgroundColor: Theme.of(context).colorScheme.primary,

          title: Text(widget.title),
        ),
        body: ListView.builder(
          physics: BouncingScrollPhysics(),
          // padding: EdgeInsets.all(5.0),
          // shrinkWrap: true,
          itemCount: name_.length,
          itemBuilder: (BuildContext context, int index) {
            return ListTile(
              onLongPress: () {
                print("long press" + index.toString());
              },
              title: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      Card(
                        child:
                        Row(
                            children: [
                              CircleAvatar(radius: 50,backgroundImage: NetworkImage(name_[index])),
                              Column(
                                children: [
                                  Padding(
                                    padding: EdgeInsets.all(5),
                                    child: Text(email_[index]),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.all(5),
                                    child: Text(phone_[index]),
                                  ),Padding(
                                    padding: EdgeInsets.all(5),
                                    child: Text(Housename_[index]),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.all(5),
                                    child: Text(place_[index]),
                                  ),
                                ],
                              ),
                              // ElevatedButton(
                              //   onPressed: () async {
                              //
                              //     final pref =await SharedPreferences.getInstance();
                              //     pref.setString("did", id_[index]);
                              //
                              //     Navigator.push(
                              //       context,
                              //       MaterialPageRoute(builder: (context) => ViewSchedule()),
                              //     );
                              //
                              //
                              //
                              //
                              //   },
                              //   child: Text("Schedule"),
                              // ),
                            ]
                        )

                        ,
                        elevation: 8,
                        margin: EdgeInsets.all(10),
                      ),
                    ],
                  )),
            );
          },
        )
      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
