import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:safe_share/view_expert.dart';
import 'package:safe_share/view_shared_content.dart';

import 'dashbord.dart';

class UserHome extends StatefulWidget {
  const UserHome({super.key});

  @override
  State<UserHome> createState() => _UserHomeState();
}

class _UserHomeState extends State<UserHome> {
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        title: Text('User Home'),
      ),
       body: SingleChildScrollView(
        child: Column(
          children: [

            ElevatedButton(onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>view_expert()));
            }, child: Text('view expert')),
            SizedBox(height: 30,),

            ElevatedButton(onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>view_shared_contentPage(title: '',)));
            }, child: Text('view shared content')),
            SizedBox(height: 30,),

            ElevatedButton(onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>view_expert()));
            }, child: Text('get notification')),
            SizedBox(height: 30,),

            ElevatedButton(onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>view_expert()));
            }, child: Text('view parant')),
            SizedBox(height: 30,),

            ElevatedButton(onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>view_expert()));
            }, child: Text('send complaints')),
            SizedBox(height: 30,),

            ElevatedButton(onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>view_expert()));
            }, child: Text('view reply')),
            SizedBox(height: 30,),

            ElevatedButton(onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>view_expert()));
            }, child: Text('sent feedback')),
            SizedBox(height: 30,),

            ElevatedButton(onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>view_expert()));
            }, child: Text('view review')),
            SizedBox(height: 30,),

            ElevatedButton(onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>view_expert()));
            }, child: Text('view post')),
            SizedBox(height: 30,),

            ElevatedButton(onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>));
            }, child: Text('view friend request')),
            SizedBox(height: 30,),
          ],


    ),
    ));


  }
}
