import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:http/http.dart' as http;

import 'login.dart';
void main(){
  runApp(ParantRegister());
}

class ParantRegister extends StatelessWidget {
  const ParantRegister ({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ParantregistrationPage(),
    );
  }
}

class ParantregistrationPage extends StatefulWidget {
  const ParantregistrationPage({super.key});

  @override
  State<ParantregistrationPage> createState() => _ParantregistrationPageState();
}

class _ParantregistrationPageState extends State<ParantregistrationPage> {


  TextEditingController studentController = new TextEditingController();
  TextEditingController  nameController = new TextEditingController();
  TextEditingController emailController = new TextEditingController();
  TextEditingController phoneController = new TextEditingController();
  TextEditingController HousenameController = new TextEditingController();
  TextEditingController placeController = new TextEditingController();
  TextEditingController unameController = new TextEditingController();
  TextEditingController passController = new TextEditingController();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:Text('Register'),
        backgroundColor: Colors.blue,
      ),

      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 20,),
            TextFormField(
              controller: studentController,
              decoration: InputDecoration(
                  hintText: 'student',
                  border: OutlineInputBorder()
              ),
            ),

            SizedBox(height: 20,),
            TextFormField(
              controller: nameController,
              decoration: InputDecoration(
                  hintText: 'name',
                  border: OutlineInputBorder()
              ),
            ),

            SizedBox(height: 20,),
            TextFormField(
              controller: emailController,
              decoration: InputDecoration(
                  hintText: 'email',
                  border: OutlineInputBorder()
              ),
            ),

            SizedBox(height: 20,),
            TextFormField(
              controller: phoneController,
              decoration: InputDecoration(
                  hintText: 'phone',
                  border: OutlineInputBorder()
              ),
            ),

            SizedBox(height: 20,),
            TextFormField(
              controller: HousenameController,
              decoration: InputDecoration(
                  hintText: 'Housename',
                  border: OutlineInputBorder()
              ),
            ),

            SizedBox(height: 20,),
            TextFormField(
              controller: placeController,
              decoration: InputDecoration(
                  hintText: ' place',
                  border: OutlineInputBorder()
              ),
            ),

            SizedBox(height: 20,),
            TextFormField(
              controller: unameController,
              decoration: InputDecoration(
                  hintText: 'Username',
                  border: OutlineInputBorder()
              ),
            ),

            SizedBox(height: 20,),
            TextFormField(
              controller: passController,
              decoration: InputDecoration(
                  hintText: 'password',
                  border: OutlineInputBorder()
              ),
            ),


            ElevatedButton(
              onPressed: () {

                _send_data();


              },
              child: Text("Register"),
            ),TextButton(
              onPressed: () {

              },
              child: Text("Signup"),
            ),

          ],
        ),
      ),
    );
  }

  void _send_data() async{


    String student=studentController.text;
    String name=nameController.text;
    String email=emailController.text;
    String phone=phoneController.text;
    String Housename=HousenameController.text;
    String place=placeController.text;
    String uname=unameController.text;
    String password=passController.text;




    SharedPreferences sh = await SharedPreferences.getInstance();
    String url = sh.getString('url').toString();

    final urls = Uri.parse('$url/myapp/android_login/');
    try {
      final response = await http.post(urls, body: {
        'student':student,
        'name':name,
        'email':email,
        'phone':phone,
        'Housename':Housename,
        'place':place,
        'uname':uname,
        'passwd':password,


      });
      if (response.statusCode == 200) {
        String status = jsonDecode(response.body)['task'];
        if (status=='valid') {


          Navigator.push(context, MaterialPageRoute(
            builder: (context) => MyLoginPage(title: "title"),));

        }else {
          Fluttertoast.showToast(msg: 'Not Found');
        }
      }
      else {
        Fluttertoast.showToast(msg: 'Network Error');
      }
    }
    catch (e){
      Fluttertoast.showToast(msg: e.toString());
    }
  }

}
